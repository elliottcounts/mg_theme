var config = {
    map: {
        '*': {
            cpowlcarousel: 'Solwin_Cpanel/js/owl.carousel',
        }
    }
};